package B02_화_SegmentTree;

public class No_10_7469_좌표압축 {
}

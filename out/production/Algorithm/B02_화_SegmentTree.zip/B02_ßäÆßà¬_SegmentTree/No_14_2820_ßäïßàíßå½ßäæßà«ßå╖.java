package B02_화_SegmentTree;

public class No_14_2820_안품 {
}

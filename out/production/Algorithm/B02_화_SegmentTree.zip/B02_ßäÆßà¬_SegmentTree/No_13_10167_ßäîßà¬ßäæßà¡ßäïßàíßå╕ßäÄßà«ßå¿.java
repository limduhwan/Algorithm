package B02_화_SegmentTree;

public class No_13_10167_좌표압축 {
}

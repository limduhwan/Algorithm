package B02_화_SegmentTree;

public class No_13_2336_안품 {
}

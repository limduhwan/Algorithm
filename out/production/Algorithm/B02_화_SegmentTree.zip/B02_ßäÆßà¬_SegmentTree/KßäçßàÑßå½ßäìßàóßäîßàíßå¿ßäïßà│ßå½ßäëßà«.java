package B02_화_SegmentTree;

public class K번째작은수 {
}

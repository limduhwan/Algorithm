package B02_화_SegmentTree;

public class No_07_2336_굉장한학생_못품 {
}

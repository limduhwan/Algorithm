package B02_화_SegmentTree;

//https://wasd222.blogspot.com/2020/03/15816.html
public class No_12_15816_좌표압축 {
}
